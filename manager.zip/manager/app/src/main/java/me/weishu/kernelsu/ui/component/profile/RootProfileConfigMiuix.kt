package me.weishu.kernelsu.ui.component.profile

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import me.weishu.kernelsu.Natives
import me.weishu.kernelsu.R
import me.weishu.kernelsu.profile.Capabilities
import me.weishu.kernelsu.profile.Groups
import me.weishu.kernelsu.toRawFlags
import me.weishu.kernelsu.toRootProfileFlags
import me.weishu.kernelsu.ui.component.miuix.SuperEditArrow
import me.weishu.kernelsu.ui.util.isSepolicyValid
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TextField
import top.yukonga.miuix.kmp.basic.TextFieldDefaults
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.preference.ArrowPreference
import top.yukonga.miuix.kmp.preference.CheckboxLocation
import top.yukonga.miuix.kmp.preference.CheckboxPreference
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme.colorScheme

@Composable
fun RootProfileConfigMiuix(
    modifier: Modifier = Modifier,
    fixedName: Boolean,
    enabled: Boolean = true,
    profile: Natives.Profile,
    onProfileChange: (Natives.Profile) -> Unit,
) {
    Column(
        modifier = modifier
    ) {
        if (!fixedName) {
            TextField(
                enabled = enabled,
                label = stringResource(R.string.profile_name),
                value = profile.name,
                onValueChange = { onProfileChange(profile.copy(name = it)) }
            )
        }

        SuperEditArrow(
            enabled = enabled,
            title = "UID",
            defaultValue = profile.uid,
        ) {
            onProfileChange(
                profile.copy(
                    uid = it,
                    rootUseDefault = false
                )
            )

        }

        SuperEditArrow(
            enabled = enabled,
            title = "GID",
            defaultValue = profile.gid,
        ) {
            onProfileChange(
                profile.copy(
                    gid = it,
                    rootUseDefault = false
                )
            )

        }

        val selectedGroups = profile.groups.let { e ->
            e.mapNotNull { g ->
                Groups.entries.find { it.gid == g }
            }
        }

        GroupsPanel(enabled, selectedGroups) {
            onProfileChange(
                profile.copy(
                    groups = it.map { group -> group.gid },
                    rootUseDefault = false
                )
            )
        }

        val selectedCaps = profile.capabilities.mapNotNull { e ->
            Capabilities.entries.find { it.cap == e }
        }

        CapsPanel(enabled, selectedCaps) {
            onProfileChange(
                profile.copy(
                    capabilities = it.map { cap -> cap.cap },
                    rootUseDefault = false
                )
            )
        }

        MountNameSpacePanel(enabled = enabled, profile = profile) {
            onProfileChange(
                profile.copy(
                    namespace = it,
                    rootUseDefault = false
                )
            )
        }

        RootProfileFlagPanel(enabled = enabled, selected = profile.flags.toRootProfileFlags()) {
            onProfileChange(
                profile.copy(
                    flags = it.toRawFlags(),
                )
            )
        }

        SELinuxPanel(enabled = enabled, profile = profile, onSELinuxChange = { domain, rules ->
            onProfileChange(
                profile.copy(
                    context = domain,
                    rules = rules,
                    rootUseDefault = false
                )
            )
        })
    }
}

@Composable
private fun GroupsPanel(
    enabled: Boolean,
    selected: List<Groups>,
    closeSelection: (selection: Set<Groups>) -> Unit
) {
    val showDialog = remember { mutableStateOf(false) }

    val groups = remember {
        Groups.entries.toTypedArray().sortedWith(
            compareBy<Groups> {
                when (it) {
                    Groups.ROOT -> 0
                    Groups.SYSTEM -> 1
                    Groups.SHELL -> 2
                    else -> Int.MAX_VALUE
                }
            }
                .then(compareBy { it.name })
        )
    }

    val currentSelection = remember(selected) { mutableStateOf(selected.toSet()) }

    OverlayDialog(
        show = showDialog.value,
        title = stringResource(R.string.profile_groups),
        summary = "${currentSelection.value.size} / 32",
        onDismissRequest = { showDialog.value = false },
        insideMargin = DpSize(0.dp, 24.dp),
        content = {
            Column(modifier = Modifier.heightIn(max = 500.dp)) {
                LazyColumn(modifier = Modifier.weight(1f, fill = false)) {
                    items(groups) { group ->
                        CheckboxPreference(
                            title = group.display,
                            summary = group.desc,
                            insideMargin = PaddingValues(horizontal = 30.dp, vertical = 16.dp),
                            checkboxLocation = CheckboxLocation.End,
                            checked = currentSelection.value.contains(group),
                            holdDownState = currentSelection.value.contains(group),
                            onCheckedChange = { isChecked ->
                                val newSelection = currentSelection.value.toMutableSet()
                                if (isChecked) {
                                    if (newSelection.size < 32) newSelection.add(group)
                                } else {
                                    newSelection.remove(group)
                                }
                                currentSelection.value = newSelection
                            }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(
                        onClick = {
                            currentSelection.value = selected.toSet()
                            showDialog.value = false
                        },
                        text = stringResource(android.R.string.cancel),
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(modifier = Modifier.width(20.dp))
                    TextButton(
                        onClick = {
                            closeSelection(currentSelection.value)
                            showDialog.value = false
                        },
                        text = stringResource(R.string.confirm),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColorsPrimary()
                    )
                }
            }
        }
    )

    val tag = if (selected.isEmpty()) {
        "None"
    } else {
        selected.joinToString(separator = ",", transform = { it.display })
    }
    ArrowPreference(
        enabled = enabled,
        title = stringResource(R.string.profile_groups),
        summary = tag,
        onClick = {
            showDialog.value = true
        }
    )

}

@Composable
private fun MountNameSpacePanel(
    enabled: Boolean,
    profile: Natives.Profile,
    onMntNamespaceChange: (namespaceType: Int) -> Unit
) {
    OverlayDropdownPreference(
        enabled = enabled,
        title = stringResource(id = R.string.profile_namespace),
        items = listOf(
            stringResource(id = R.string.profile_namespace_inherited),
            stringResource(id = R.string.profile_namespace_global),
            stringResource(id = R.string.profile_namespace_individual),
        ),
        selectedIndex = profile.namespace, onSelectedIndexChange = { index ->
            onMntNamespaceChange(index)
        }
    )
}

@Composable
private fun RootProfileFlagPanel(
    enabled: Boolean,
    selected: List<Natives.Profile.RootProfileFlag>,
    closeSelection: (selection: List<Natives.Profile.RootProfileFlag>) -> Unit
) {
    val showDialog = remember { mutableStateOf(false) }

    val caps = remember {
        Natives.Profile.RootProfileFlag.entries.toTypedArray().sortedBy { it.display }
    }

    val currentSelection = remember(selected) { mutableStateOf(selected.toSet()) }

    OverlayDialog(
        show = showDialog.value,
        title = stringResource(R.string.profile_flags),
        onDismissRequest = { showDialog.value = false },
        insideMargin = DpSize(0.dp, 24.dp),
        content = {
            Column(modifier = Modifier.heightIn(max = 500.dp)) {
                LazyColumn(modifier = Modifier.weight(1f, fill = false)) {
                    items(caps) { cap ->
                        CheckboxPreference(
                            title = cap.display,
                            summary = stringResource(cap.desc),
                            insideMargin = PaddingValues(horizontal = 30.dp, vertical = 16.dp),
                            checkboxLocation = CheckboxLocation.End,
                            checked = currentSelection.value.contains(cap),
                            holdDownState = currentSelection.value.contains(cap),
                            onCheckedChange = { isChecked ->
                                val newSelection = currentSelection.value.toMutableSet()
                                if (isChecked) {
                                    newSelection.add(cap)
                                } else {
                                    newSelection.remove(cap)
                                }
                                currentSelection.value = newSelection
                            }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(
                        onClick = {
                            showDialog.value = false
                            currentSelection.value = selected.toSet()
                        },
                        text = stringResource(android.R.string.cancel),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(20.dp))
                    TextButton(
                        onClick = {
                            closeSelection(currentSelection.value.toList())
                            showDialog.value = false
                        },
                        text = stringResource(R.string.confirm),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColorsPrimary()
                    )
                }
            }
        }
    )

    val tag = if (selected.isEmpty()) {
        "None"
    } else {
        selected.joinToString(separator = ",", transform = { it.display })
    }
    ArrowPreference(
        enabled = enabled,
        title = stringResource(R.string.profile_flags),
        summary = tag,
        onClick = {
            showDialog.value = true
        }
    )

}

@Composable
private fun CapsPanel(
    enabled: Boolean,
    selected: Collection<Capabilities>,
    closeSelection: (selection: Set<Capabilities>) -> Unit
) {
    val showDialog = remember { mutableStateOf(false) }

    val caps = remember {
        Capabilities.entries.toTypedArray().sortedBy { it.display }
    }

    val currentSelection = remember(selected) { mutableStateOf(selected.toSet()) }

    OverlayDialog(
        show = showDialog.value,
        title = stringResource(R.string.profile_capabilities),
        onDismissRequest = { showDialog.value = false },
        insideMargin = DpSize(0.dp, 24.dp),
        content = {
            Column(modifier = Modifier.heightIn(max = 500.dp)) {
                LazyColumn(modifier = Modifier.weight(1f, fill = false)) {
                    items(caps) { cap ->
                        CheckboxPreference(
                            title = cap.display,
                            summary = cap.desc,
                            insideMargin = PaddingValues(horizontal = 30.dp, vertical = 16.dp),
                            checkboxLocation = CheckboxLocation.End,
                            checked = currentSelection.value.contains(cap),
                            holdDownState = currentSelection.value.contains(cap),
                            onCheckedChange = { isChecked ->
                                val newSelection = currentSelection.value.toMutableSet()
                                if (isChecked) {
                                    newSelection.add(cap)
                                } else {
                                    newSelection.remove(cap)
                                }
                                currentSelection.value = newSelection
                            }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(
                        onClick = {
                            showDialog.value = false
                            currentSelection.value = selected.toSet()
                        },
                        text = stringResource(android.R.string.cancel),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(20.dp))
                    TextButton(
                        onClick = {
                            closeSelection(currentSelection.value)
                            showDialog.value = false
                        },
                        text = stringResource(R.string.confirm),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColorsPrimary()
                    )
                }
            }
        }
    )

    val tag = if (selected.isEmpty()) {
        "None"
    } else {
        selected.joinToString(separator = ",", transform = { it.display })
    }
    ArrowPreference(
        enabled = enabled,
        title = stringResource(R.string.profile_capabilities),
        summary = tag,
        onClick = {
            showDialog.value = true
        }
    )

}

@Composable
private fun SELinuxPanel(
    enabled: Boolean,
    profile: Natives.Profile,
    onSELinuxChange: (domain: String, rules: String) -> Unit
) {
    val showDialog = remember { mutableStateOf(false) }

    var domain by remember(profile.context) { mutableStateOf(profile.context) }
    var rules by remember(profile.rules) { mutableStateOf(profile.rules) }

    val isDomainValid = remember(domain) {
        val regex = Regex("^[a-z_]+:[a-z0-9_]+:[a-z0-9_]+(:[a-z0-9_]+)?$")
        domain.matches(regex)
    }
    val isRulesValid = remember(rules) { isSepolicyValid(rules) }

    OverlayDialog(
        show = showDialog.value,
        title = stringResource(R.string.profile_selinux_context),
        onDismissRequest = { showDialog.value = false },
        content = {
            Column(modifier = Modifier.heightIn(max = 500.dp)) {
                Column(modifier = Modifier.weight(1f, fill = false)) {
                    TextField(
                        value = domain,
                        onValueChange = { domain = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        label = stringResource(id = R.string.profile_selinux_domain),
                        colors = TextFieldDefaults.textFieldColors(
                            borderColor = if (isDomainValid) {
                                colorScheme.primary
                            } else {
                                Color.Red.copy(alpha = if (isSystemInDarkTheme()) 0.3f else 0.6f)
                            },
                        ),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Ascii,
                            imeAction = ImeAction.Next
                        ),
                        singleLine = true
                    )
                    TextField(
                        value = rules,
                        onValueChange = { rules = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        label = stringResource(id = R.string.profile_selinux_rules),
                        colors = TextFieldDefaults.textFieldColors(
                            borderColor = if (isRulesValid) {
                                colorScheme.primary
                            } else {
                                Color.Red.copy(alpha = if (isSystemInDarkTheme()) 0.3f else 0.6f)
                            },
                        ),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Ascii,
                        ),
                        singleLine = false
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(
                        onClick = { showDialog.value = false },
                        text = stringResource(android.R.string.cancel),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(20.dp))
                    TextButton(
                        onClick = {
                            onSELinuxChange(domain, rules)
                            showDialog.value = false
                        },
                        text = stringResource(R.string.confirm),
                        enabled = isDomainValid && isRulesValid,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColorsPrimary()
                    )
                }
            }
        }
    )

    ArrowPreference(
        enabled = enabled,
        title = stringResource(R.string.profile_selinux_context),
        summary = profile.context,
        onClick = { showDialog.value = true }
    )
}
